import { McpServer } from "@modelcontextprotocol/server";
import { LineBotClient } from "@line/bot-sdk";
import {
  createErrorResponse,
  createSuccessResponse,
} from "../common/response.js";
import { AbstractTool } from "./AbstractTool.js";
import { z } from "zod";

export default class DeleteRichMenu extends AbstractTool {
  private client: LineBotClient;

  constructor(client: LineBotClient) {
    super();
    this.client = client;
  }

  register(server: McpServer) {
    const richMenuIdSchema = z
      .string()
      .describe("The ID of the rich menu to delete.");

    server.registerTool(
      "delete_rich_menu",
      {
        title: "Delete Rich Menu",
        description: "Delete a rich menu from your LINE Official Account.",
        inputSchema: z.object({
          richMenuId: richMenuIdSchema.describe(
            "The ID of the rich menu to delete.",
          ),
        }),
        annotations: {
          destructiveHint: true,
        },
      },
      async ({ richMenuId }) => {
        try {
          const response = await this.client.deleteRichMenu(richMenuId);
          return createSuccessResponse(response);
        } catch (error: unknown) {
          return createErrorResponse(
            `Failed to delete rich menu: ${error instanceof Error ? error.message : String(error)}`,
          );
        }
      },
    );
  }
}
