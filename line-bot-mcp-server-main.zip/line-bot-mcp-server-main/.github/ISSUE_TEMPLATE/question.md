---
name: "Question Template"
about: "Use this template to ask questions about usage or implementation of the line-bot-mcp-server."
title: "Question"
---

<!--
## Before Creating a Question Issue
- Please check the [developer documentation](https://developers.line.biz/en/docs/) and [FAQ](https://developers.line.biz/en/faq/tags/messaging-api/) for answers to common questions.
- Make sure your question hasn't already been asked in other Issues or the documentation.
## This Is Not
- A bug report. If you think you've found a bug, please use the "Bug Report" template.
- A place to request new features. If you have a feature request, consider opening a "Feature Request" issue or PR.
## When Creating a Question
- Provide detailed information about your environment and context so we can better understand and answer your question.
- Let us know what you've tried so far (e.g. searching docs, existing issues, etc.).
-->

## Have You Checked the Following?
- [ ] [Developer Documentation - LINE Developers](https://developers.line.biz/en/docs/)
- [ ] [FAQ - LINE Developers](https://developers.line.biz/en/faq/tags/messaging-api/)

## Summary of Your Question
<!-- Provide a clear and concise description of what you want to know. -->

## Details
<!-- Provide any prompt, code snippets, relevant logs, or background details that will help us understand your question better. -->

## What You've Tried
<!-- Let us know any steps you've already taken to answer your own question, 
     such as searching in documentation or checking existing issues. -->

## Your Environment
<!-- For example:
 - OS: [e.g. Ubuntu]
 - Node.js Version [e.g. Node 22]
 - line-bot-mcp-server version(s) [e.g. 0.0.1]
 - AI Agent you use [e.g. Claude for Desktop]
-->

## Additional Context (Optional)
<!-- Add any other context, possible considerations, or related links here. -->
