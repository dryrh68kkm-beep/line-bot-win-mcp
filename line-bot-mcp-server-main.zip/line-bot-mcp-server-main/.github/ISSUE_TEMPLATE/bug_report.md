---
name: Bug Report Template
about: Use this template to report bugs in the line-bot-mcp-server
title: 'Bug Report'
---

## Bug Report
 <!--
## Before Creating an Issue
- Please check our [developer documentation](https://developers.line.biz/en/docs/) and [FAQ](https://developers.line.biz/en/faq/tags/messaging-api/) for more information on the Messaging API
- Make sure the issue you are reporting isn't already addressed in the documentation or existing issues.
## When Creating an Issue
- Provide detailed information about the issue you experienced with the MCP Server using the template below.
-->

## System Information
 - OS: [e.g. Ubuntu]
 - Node.js Version [e.g. Node 22]
 - line-bot-mcp-server version(s) [e.g. 0.0.1]
 - AI Agent you use [e.g. Claude for Desktop]

## Expected Behavior
<!-- Describe what you expected to happen -->

## Current Behavior
<!-- Describe what actually happened instead of the expected behavior -->

## Steps to Reproduce
<!-- Provide a link to a live example or a clear set of steps to reproduce the issue.
     If possible, provide minimal code (e.g. test code, a draft PR, or a link to a forked repository) or prompt. -->
1.
2.
3.

## Logs
<!-- If possible, provide logs to help identify the issue -->

## Additional Context (Optional)
<!-- Add any other context or information that might be relevant to the issue.
     For example, related issues, potential causes, or possible solutions. -->
